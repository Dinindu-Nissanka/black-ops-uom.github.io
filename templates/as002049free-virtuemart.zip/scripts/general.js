
/***************************************************************************************/
/*
/*		Designed by 'AS Designing'
/*		Web: http://www.asdesigning.com
/*		Email: info@asdesigning.com
/*		License: Creative Commons
/*
/**************************************************************************************/

var asjQuery = jQuery.noConflict();

asjQuery(window).load(function() 
{
	asjQuery("#phocagallery-module-ri").css("margin", "0px auto");	
	
	jQuery("<li class='bgtop'></li>").prependTo("#topmenu ul.menu ul");
	jQuery("<li class='bgbottom'></li>").appendTo("#topmenu ul.menu ul");			
	asjQuery(".menu li").fadeIn(1);	
});

	
asjQuery(document).ready(function()
{
	asjQuery(".toggle.1").click(function(){
		asjQuery(".toggle_content.1").slideToggle();
		if(asjQuery(".toggle.1").hasClass("opened"))
			asjQuery(".toggle.1").removeClass("opened")	
		else
			asjQuery(".toggle.1").addClass("opened")
	});
	asjQuery(".toggle.2").click(function(){
		asjQuery(".toggle_content.2").slideToggle();
		if(asjQuery(".toggle.2").hasClass("opened"))
			asjQuery(".toggle.2").removeClass("opened")	
		else
			asjQuery(".toggle.2").addClass("opened")
	});
	asjQuery(".toggle.3").click(function(){
		asjQuery(".toggle_content.3").slideToggle();
		if(asjQuery(".toggle.3").hasClass("opened"))
			asjQuery(".toggle.3").removeClass("opened")	
		else
			asjQuery(".toggle.3").addClass("opened")
	});
	asjQuery(".toggle.4").click(function(){
		asjQuery(".toggle_content.4").slideToggle();
		if(asjQuery(".toggle.4").hasClass("opened"))
			asjQuery(".toggle.4").removeClass("opened")	
		else
			asjQuery(".toggle.4").addClass("opened")
	});
	asjQuery(".toggle.5").click(function(){
		asjQuery(".toggle_content.5").slideToggle();
		if(asjQuery(".toggle.5").hasClass("opened"))
			asjQuery(".toggle.5").removeClass("opened")	
		else
			asjQuery(".toggle.5").addClass("opened")
	});
	asjQuery(".toggle.6").click(function(){
		asjQuery(".toggle_content.6").slideToggle();
		if(asjQuery(".toggle.6").hasClass("opened"))
			asjQuery(".toggle.6").removeClass("opened")	
		else
			asjQuery(".toggle.6").addClass("opened")
	});
	asjQuery(".toggle.7").click(function(){
		asjQuery(".toggle_content.7").slideToggle();
		if(asjQuery(".toggle.7").hasClass("opened"))
			asjQuery(".toggle.7").removeClass("opened")	
		else
			asjQuery(".toggle.7").addClass("opened")
	});
	asjQuery(".toggle.8").click(function(){
		asjQuery(".toggle_content.8").slideToggle();
		if(asjQuery(".toggle.8").hasClass("opened"))
			asjQuery(".toggle.8").removeClass("opened")	
		else
			asjQuery(".toggle.8").addClass("opened")
	});
	asjQuery(".toggle.9").click(function(){
		asjQuery(".toggle_content.9").slideToggle();
		if(asjQuery(".toggle.9").hasClass("opened"))
			asjQuery(".toggle.9").removeClass("opened")	
		else
			asjQuery(".toggle.9").addClass("opened")
	});
	asjQuery(".toggle.10").click(function(){
		asjQuery(".toggle_content.10").slideToggle();
		if(asjQuery(".toggle.10").hasClass("opened"))
			asjQuery(".toggle.10").removeClass("opened")	
		else
			asjQuery(".toggle.10").addClass("opened")
	});
	asjQuery(".toggle.11").click(function(){
		asjQuery(".toggle_content.11").slideToggle();
		if(asjQuery(".toggle.11").hasClass("opened"))
			asjQuery(".toggle.11").removeClass("opened")	
		else
			asjQuery(".toggle.11").addClass("opened")
	});
	asjQuery(".toggle.12").click(function(){
		asjQuery(".toggle_content.12").slideToggle();
		if(asjQuery(".toggle.12").hasClass("opened"))
			asjQuery(".toggle.12").removeClass("opened")	
		else
			asjQuery(".toggle.12").addClass("opened")
	});
	asjQuery(".toggle.13").click(function(){
		asjQuery(".toggle_content.13").slideToggle();
		if(asjQuery(".toggle.13").hasClass("opened"))
			asjQuery(".toggle.13").removeClass("opened")	
		else
			asjQuery(".toggle.13").addClass("opened")
	});
	asjQuery(".toggle.14").click(function(){
		asjQuery(".toggle_content.14").slideToggle();
		if(asjQuery(".toggle.14").hasClass("opened"))
			asjQuery(".toggle.14").removeClass("opened")	
		else
			asjQuery(".toggle.14").addClass("opened")
	});
	asjQuery(".toggle.15").click(function(){
		asjQuery(".toggle_content.15").slideToggle();
		if(asjQuery(".toggle.15").hasClass("opened"))
			asjQuery(".toggle.15").removeClass("opened")	
		else
			asjQuery(".toggle.15").addClass("opened")
	});
	asjQuery(".toggle.16").click(function(){
		asjQuery(".toggle_content.16").slideToggle();
		if(asjQuery(".toggle.16").hasClass("opened"))
			asjQuery(".toggle.16").removeClass("opened")	
		else
			asjQuery(".toggle.16").addClass("opened")
	});
	asjQuery(".toggle.17").click(function(){
		asjQuery(".toggle_content.17").slideToggle();
		if(asjQuery(".toggle.17").hasClass("opened"))
			asjQuery(".toggle.17").removeClass("opened")	
		else
			asjQuery(".toggle.17").addClass("opened")
	});
	asjQuery(".toggle.18").click(function(){
		asjQuery(".toggle_content.18").slideToggle();
		if(asjQuery(".toggle.18").hasClass("opened"))
			asjQuery(".toggle.18").removeClass("opened")	
		else
			asjQuery(".toggle.18").addClass("opened")
	});
	asjQuery(".toggle.19").click(function(){
		asjQuery(".toggle_content.19").slideToggle();
		if(asjQuery(".toggle.19").hasClass("opened"))
			asjQuery(".toggle.19").removeClass("opened")	
		else
			asjQuery(".toggle.19").addClass("opened")
	});
	asjQuery(".toggle.20").click(function(){
		asjQuery(".toggle_content.20").slideToggle();
		if(asjQuery(".toggle.20").hasClass("opened"))
			asjQuery(".toggle.20").removeClass("opened")	
		else
			asjQuery(".toggle.20").addClass("opened")
	});
	asjQuery(".toggle.21").click(function(){
		asjQuery(".toggle_content.21").slideToggle();
		if(asjQuery(".toggle.21").hasClass("opened"))
			asjQuery(".toggle.21").removeClass("opened")	
		else
			asjQuery(".toggle.21").addClass("opened")
	});
	asjQuery(".toggle.22").click(function(){
		asjQuery(".toggle_content.22").slideToggle();
		if(asjQuery(".toggle.22").hasClass("opened"))
			asjQuery(".toggle.22").removeClass("opened")	
		else
			asjQuery(".toggle.22").addClass("opened")
	});
	asjQuery(".toggle.23").click(function(){
		asjQuery(".toggle_content.23").slideToggle();
		if(asjQuery(".toggle.23").hasClass("opened"))
			asjQuery(".toggle.23").removeClass("opened")	
		else
			asjQuery(".toggle.23").addClass("opened")
	});
	asjQuery(".toggle.24").click(function(){
		asjQuery(".toggle_content.24").slideToggle();
		if(asjQuery(".toggle.24").hasClass("opened"))
			asjQuery(".toggle.24").removeClass("opened")	
		else
			asjQuery(".toggle.24").addClass("opened")
	});
	asjQuery(".toggle.25").click(function(){
		asjQuery(".toggle_content.25").slideToggle();
		if(asjQuery(".toggle.25").hasClass("opened"))
			asjQuery(".toggle.25").removeClass("opened")	
		else
			asjQuery(".toggle.25").addClass("opened")
	});	
});

asjQuery(document).ready(function()
{
	asjQuery('#topmenu ul li.deeper').hover(
		function() {
			asjQuery(this).addClass("actives");
			asjQuery(this).find('>ul').stop(false, true).fadeIn();
			asjQuery(this).find('>ul ul').stop(false, true).fadeOut('fast');
		},
		function() {
			asjQuery(this).removeClass("actives");        
			asjQuery(this).find('ul').stop(false, true).fadeOut('fast');
		}
	);
});


asjQuery(document).ready(function()
{
    asjQuery(".tab1").click(function(){
        asjQuery(".tab1_content").addClass("opened");
        asjQuery(".tab2_content").addClass("closed");
        asjQuery(".tab3_content").addClass("closed");
        asjQuery(".tab1_content").removeClass("closed");
        asjQuery(".tab2_content").removeClass("opened");
        asjQuery(".tab3_content").removeClass("opened");
    });
    asjQuery(".tab2").click(function(){
        asjQuery(".tab2_content").addClass("opened");
        asjQuery(".tab1_content").addClass("closed");
        asjQuery(".tab3_content").addClass("closed");
        asjQuery(".tab2_content").removeClass("closed");
        asjQuery(".tab1_content").removeClass("opened");
        asjQuery(".tab3_content").removeClass("opened");
    });
    asjQuery(".tab3").click(function(){
        asjQuery(".tab3_content").addClass("opened");
        asjQuery(".tab1_content").addClass("closed");
        asjQuery(".tab2_content").addClass("closed");
        asjQuery(".tab3_content").removeClass("closed");
        asjQuery(".tab1_content").removeClass("opened");
        asjQuery(".tab2_content").removeClass("opened");
    });
    
});


