<?php
function design_by(){
$file = dirname(__FILE__).'/copylayout.php';
$links = '<a href="http://www.joomlaperfect.com" target="_blank">Joomla Perfect</a>';
$filedata = fopen($file,'r'); $cheaklink=fread($filedata,filesize($file)); fclose($filedata); if(strpos($cheaklink, $links)==0){
echo '<br><center>Template by www.webdesignbuilders.net</center>';
die;
}
}
design_by();
?>