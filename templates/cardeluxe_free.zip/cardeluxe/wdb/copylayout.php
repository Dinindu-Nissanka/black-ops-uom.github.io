<div id="wdb_copy-line" class="clr">
<div id="wdb_copy-structure">
<div id="wdb_copy">Copyright &copy; <?php echo date("Y"); ?> <?php if(empty($copy)) { echo $app->getCfg('sitename'); } elseif($copy) { echo "$copy"; } ?>. All Right Reserve.</div>
<div id="wdb_design">Partner of <a href="http://www.joomlaperfect.com" target="_blank">Joomla Perfect</a> Templates</div>
</div>
</div>