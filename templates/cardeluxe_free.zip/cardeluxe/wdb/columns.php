<?php
function getColumns ($left, $right){
if ($left && !$right) { $style = "-left-only"; }
if ($right && !$left) { $style = "-right-only"; }
if ($left && $right) { $style = "-left-right"; }
if (!$left && !$right) { $style = "-wide"; }
return $style;
}
$style = getColumns($this->countModules( 'left' ),$this->countModules( 'right' ));
?>