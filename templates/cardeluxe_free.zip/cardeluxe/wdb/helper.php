<?php
$app = JFactory::getApplication();
$doc = JFactory::getDocument();
$menutype = $this->params->get('menutype');
$copy = $this->params->get('copy');
$logo = $this->params->get('logo');
include dirname(__FILE__).DIRECTORY_SEPARATOR.'multiblocks.php';
include dirname(__FILE__).DIRECTORY_SEPARATOR.'columns.php';
include dirname(__FILE__).DIRECTORY_SEPARATOR.'remove.php';
include dirname(__FILE__).DIRECTORY_SEPARATOR.'built.php';
include dirname(__FILE__).DIRECTORY_SEPARATOR.'protect.php';
$copylayout = dirname(__FILE__).DIRECTORY_SEPARATOR.'copylayout.php';
?>