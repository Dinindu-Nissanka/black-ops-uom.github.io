<?php
$doc->addStyleSheet(JUri::base() . 'templates/system/css/system.css', $type = 'text/css');
$doc->addStyleSheet(JUri::base() . 'templates/' . $this->template . '/css/template.css', $type = 'text/css');
$doc->addStyleSheet(JUri::base() . 'templates/' . $this->template . '/css/default.css', $type = 'text/css');
$doc->addStyleSheet(JUri::base() . 'templates/' . $this->template . '/css/config.css', $type = 'text/css');
$doc->addStyleSheet(JUri::base() . 'templates/' . $this->template . '/css/toolbar.css', $type = 'text/css');
$doc->addStyleSheet(JUri::base() . 'templates/' . $this->template . '/css/modules.css', $type = 'text/css');
$doc->addStyleSheet(JUri::base() . 'templates/' . $this->template . '/css/font.css', $type = 'text/css');
$doc->addStyleSheet(JUri::base() . 'templates/' . $this->template . '/css/styles/style1.css', $type = 'text/css');
$doc->addScript($this->baseurl . '/templates/' . $this->template . '/js/jquery.js', 'text/javascript');
$doc->addScript($this->baseurl . '/templates/' . $this->template . '/js/' . "$menutype" . '.js', 'text/javascript');
?>