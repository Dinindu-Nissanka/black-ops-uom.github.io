<?php defined('_JEXEC') or die('Restricted access'); JHtml::_('behavior.framework', true); ?>
<?php require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'wdb/helper.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
<head>
<jdoc:include type="head" />
</head>

<body class="<?php echo $this->params->get('fontfamily'); ?> <?php echo $this->params->get('fontsize'); ?>">
<?php if($this->countModules('topmenu') or $this->countModules('topright')) : ?>
<div id="wdb_top-line" class="clr">
<div id="wdb_top-structure">
<div id="wdb_topmenu">
<jdoc:include type="modules" name="topmenu" style="none" />
</div>
<div id="wdb_topright">
<jdoc:include type="modules" name="topright" style="none" />
</div>
</div>
</div>
<?php endif; ?>
<div id="wdb_header-line" class="clr">
<div id="wdb_header-structure">
<div id="wdb_logo">
<img style="height:100px;" src="<?php echo $this->baseurl ?>/<?php echo "$logo"; ?>" />
</div>
<div id="wdb_header">
<jdoc:include type="modules" name="header" style="none" />
</div>
</div>
</div>
<?php if($this->countModules('toolbar') or $this->countModules('search')) : ?>
<div id="wdb_toolbar-line" class="clr">
<div id="wdb_toolbar-structure">
<div id="wdb_toolbar">
<jdoc:include type="modules" name="toolbar" style="none" />
</div>
<?php if($this->countModules('search')) : ?>
<div id="wdb_search">
<jdoc:include type="modules" name="search" style="none" />
</div>
<?php endif; ?>
</div>
</div>
<div id="wdb_spacer-line" class="clr">
<div id="wdb_spacer-structure">
&nbsp;
</div>
</div>
<?php endif; ?>
<?php if($this->countModules('banner')) : ?>
<div id="wdb_banner-line" class="clr">
<div id="wdb_banner-structure">
<jdoc:include type="modules" name="banner" style="none" />
</div>
</div>
<?php endif; ?>
<?php $mClasses = modulesClasses('block1'); if ($this->countModules('advert1') or $this->countModules('advert2') or $this->countModules('advert3') or $this->countModules('advert4') or $this->countModules('advert5')) : ?>
<div id="wdb_advert-line" class="clr">
<div id="wdb_advert-bg">
<div id="wdb_advert-structure">
<div class="<?php echo $advert_width; ?>">
<?php if($this->countModules('advert1')) : ?>
<div class="wdb_advert <?php echo $mClasses['advert1'][0]; ?>">
<jdoc:include type="modules" name="advert1" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('advert2')) : ?>
<div class="wdb_advert <?php echo $mClasses['advert2'][0]; ?>">
<jdoc:include type="modules" name="advert2" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('advert3')) : ?>
<div class="wdb_advert <?php echo $mClasses['advert3'][0]; ?>">
<jdoc:include type="modules" name="advert3" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('advert4')) : ?>
<div class="wdb_advert <?php echo $mClasses['advert4'][0]; ?>">
<jdoc:include type="modules" name="advert4" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('advert5')) : ?>
<div class="wdb_advert <?php echo $mClasses['advert5'][0]; ?>">
<jdoc:include type="modules" name="advert5" style="xhtml" />
</div>
<?php endif; ?>
</div>
</div>
</div>
</div>
<?php endif; ?>
<div id="wdb_body-line" class="clr">
<div id="wdb_body-structure">
<div id="wdb_body-bg">
<?php if($this->countModules('left')) : ?>
<div id="wdb_left<?php echo $style; ?>">
<jdoc:include type="modules" name="left" style="xhtml" />
</div>
<?php endif; ?>
<div id="wdb_body<?php echo $style; ?>">
<?php $mClasses = modulesClasses('block2'); if ($this->countModules('user1') or $this->countModules('user2') or $this->countModules('user3')) : ?>
<div id="wdb_user<?php echo $style; ?>" class="clr">
<div class="<?php echo $user_width; ?>">
<?php if($this->countModules('user1')) : ?>
<div class="wdb_user <?php echo $mClasses['user1'][0]; ?>">
<jdoc:include type="modules" name="user1" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('user2')) : ?>
<div class="wdb_user <?php echo $mClasses['user2'][0]; ?>">
<jdoc:include type="modules" name="user2" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('user3')) : ?>
<div class="wdb_user <?php echo $mClasses['user3'][0]; ?>">
<jdoc:include type="modules" name="user3" style="xhtml" />
</div>
<?php endif; ?>
</div>
</div>
<?php endif; ?>
<?php $mClasses = modulesClasses('block3'); if ($this->countModules('user4') or $this->countModules('user5') or $this->countModules('user6')) : ?>
<div id="wdb_user<?php echo $style; ?>" class="clr">
<div class="<?php echo $user2_width; ?>">
<?php if($this->countModules('user4')) : ?>
<div class="wdb_user <?php echo $mClasses['user4'][0]; ?>">
<jdoc:include type="modules" name="user4" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('user5')) : ?>
<div class="wdb_user <?php echo $mClasses['user5'][0]; ?>">
<jdoc:include type="modules" name="user5" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('user6')) : ?>
<div class="wdb_user <?php echo $mClasses['user6'][0]; ?>">
<jdoc:include type="modules" name="user6" style="xhtml" />
</div>
<?php endif; ?>
</div>
</div>
<?php endif; ?>
<div id="wdb_content" class="clr">
<jdoc:include type="message" />
<jdoc:include type="component" />
</div>
<?php $mClasses = modulesClasses('block4'); if ($this->countModules('user7') or $this->countModules('user8') or $this->countModules('user9')) : ?>
<div id="wdb_user<?php echo $style; ?>" class="clr">
<div class="<?php echo $user3_width; ?>">
<?php if($this->countModules('user7')) : ?>
<div class="wdb_user <?php echo $mClasses['user7'][0]; ?>">
<jdoc:include type="modules" name="user7" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('user8')) : ?>
<div class="wdb_user <?php echo $mClasses['user8'][0]; ?>">
<jdoc:include type="modules" name="user8" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('user9')) : ?>
<div class="wdb_user <?php echo $mClasses['user9'][0]; ?>">
<jdoc:include type="modules" name="user9" style="xhtml" />
</div>
<?php endif; ?>
</div>
</div>
<?php endif; ?>
</div>
<?php if($this->countModules('right')) : ?>
<div id="wdb_right<?php echo $style; ?>">
<jdoc:include type="modules" name="right" style="xhtml" />
</div>
<?php endif; ?>
</div>
</div>
</div>
<?php $mClasses = modulesClasses('block5'); if ($this->countModules('footer1') or $this->countModules('footer2') or $this->countModules('footer3') or $this->countModules('footer4') or $this->countModules('footer5')) : ?>
<div id="wdb_footer-line" class="clr">
<div id="wdb_footer-bg">
<div id="wdb_footer-structure">
<div class="<?php echo $footer_width; ?>">
<?php if($this->countModules('footer1')) : ?>
<div class="wdb_footer <?php echo $mClasses['footer1'][0]; ?>">
<jdoc:include type="modules" name="footer1" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('footer2')) : ?>
<div class="wdb_footer <?php echo $mClasses['footer2'][0]; ?>">
<jdoc:include type="modules" name="footer2" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('footer3')) : ?>
<div class="wdb_footer <?php echo $mClasses['footer3'][0]; ?>">
<jdoc:include type="modules" name="footer3" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('footer4')) : ?>
<div class="wdb_footer <?php echo $mClasses['footer4'][0]; ?>">
<jdoc:include type="modules" name="footer4" style="xhtml" />
</div>
<?php endif; ?>
<?php if($this->countModules('footer5')) : ?>
<div class="wdb_footer <?php echo $mClasses['footer5'][0]; ?>">
<jdoc:include type="modules" name="footer5" style="xhtml" />
</div>
<?php endif; ?>
</div>
</div>
</div>
</div>
<?php endif; ?>
<?php include("$copylayout"); ?>
<div style="height:25px;" class="clr">&nbsp;</div>
</body>
</html>