<?php // no direct access
/** 
# @author Bryan Keller
# Email : admin@sanantoniocomputerrepair.net
# URL : www.frontallobemarketing.com
# Copyright (c) 2014 Frontal Lobe Marketing
# License GNU GPL
*/

defined( '_JEXEC' ) or die( 'Restricted access' ); 

echo $slidesocialconnect;
?>