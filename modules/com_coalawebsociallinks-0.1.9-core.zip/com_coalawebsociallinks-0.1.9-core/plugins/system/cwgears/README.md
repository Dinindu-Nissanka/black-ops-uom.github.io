cw-gears
========

This plugin provides the base framework for CoalaWeb extensions.
