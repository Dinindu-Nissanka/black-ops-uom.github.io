CoalaWeb Social Links
===============

CoalaWeb Social Links is a complete social media package to help your site visitors bookmark content, follow you through a variety of social networks and vote for particular content with social buttons.
